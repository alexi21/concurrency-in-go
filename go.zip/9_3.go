package main

import "fmt"

func main() {
	c := make(chan int, 1)

	recv := <-c

	fmt.Println(recv)
}
