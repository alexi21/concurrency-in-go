package main

import "fmt"

func main() {
	c := make(chan int)

	recv := <-c

	fmt.Println(recv)
}
